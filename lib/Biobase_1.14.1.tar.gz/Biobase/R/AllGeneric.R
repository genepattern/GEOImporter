setGeneric("abstract",        function(object) standardGeneric("abstract"))
setGeneric("addVarMetadataEntry", function(object,vname,attname, attval) standardGeneric("addVarMetadataEntry"))
setGeneric("aggenv",          function(object) standardGeneric("aggenv"))
setGeneric("aggfun",          function(object) standardGeneric("aggfun"))
setGeneric("annotation",      function(object) standardGeneric("annotation"))
setGeneric("annotation<-",    function(object, value) standardGeneric("annotation<-"))
setGeneric("annotatedDataFrameFrom", function(object, byrow, ...) standardGeneric("annotatedDataFrameFrom"))
setGeneric("as.data.frame.exprSet", function(x, row.names=NULL, optional=FALSE, ...) standardGeneric("as.data.frame.exprSet"))
setGeneric("assayData",       function(object)standardGeneric("assayData"))
setGeneric("assayData<-",     function(object, value) standardGeneric("assayData<-"))
setGeneric("combine",
   function(x, y, ...) {
      if (length(list(...)) > 0)
         combine( x, combine( y, combine(...) ) )
      else
         standardGeneric("combine")
   }
)
setGeneric("content",         function(object) standardGeneric("content"))
setGeneric("convertVarLabels",function(object) standardGeneric("convertVarLabels"))
setGeneric("description",     function(object) standardGeneric("description"))
setGeneric("description<-",   function(object, value) standardGeneric("description<-"))
setGeneric("dims",            function(object) standardGeneric("dims"))
setGeneric("dimLabels",       function(object) standardGeneric("dimLabels"))
setGeneric("eList",           function(object) standardGeneric("eList"))
setGeneric("eList<-",         function(object, value) standardGeneric("eList<-"))
setGeneric("experimentData",  function(object) standardGeneric("experimentData"))
setGeneric("experimentData<-",function(object, value) standardGeneric("experimentData<-"))
setGeneric("expinfo",         function(object) standardGeneric("expinfo"))
setGeneric("exprs",           function(object) standardGeneric("exprs"))
setGeneric("exprs<-",         function(object, value) standardGeneric("exprs<-"))
setGeneric("exprs2excel",     function(x,...) standardGeneric("exprs2excel"))
setGeneric("featureNames",    function(object) standardGeneric("featureNames"))
setGeneric("featureNames<-",  function(object, value) standardGeneric("featureNames<-"))
setGeneric("featureData",     function(object) standardGeneric("featureData"))
setGeneric("featureData<-",   function(object, value) standardGeneric("featureData<-"))
setGeneric("geneNames",       function(object) standardGeneric("geneNames"))
setGeneric("geneNames<-",     function(object, value) standardGeneric("geneNames<-"))
setGeneric("getExpData",      function(object, name) standardGeneric("getExpData"))
setGeneric("getUnits",        function(object, vname) standardGeneric("getUnits"))
setGeneric("getVarMetadata",  function(object, vname, attname) standardGeneric("getVarMetadata"))
setGeneric("hybridizations",  function(object) standardGeneric("hybridizations"))
setGeneric("initfun",         function(object) standardGeneric("initfun"))
setGeneric("iter",            function(object, covlab, f) standardGeneric("iter"))
setGeneric("locked",          function(object) standardGeneric("locked"))
setGeneric("makeDataPackage", function(object, author, email,
                                       packageName=deparse(substitute(object)),
                                       packageVersion=package_version("1.0.0"),
                                       license="The Artistic License, Version 2.0",
                                       biocViews="ExperimentData",
                                       filePath=tempdir(), ...) standardGeneric("makeDataPackage"),
           signature="object")
setGeneric("normControls",    function(object) standardGeneric("normControls"))
setGeneric("notes",           function(object) standardGeneric("notes"))
setGeneric("notes<-",         function(object, value) standardGeneric("notes<-"))
setGeneric("otherInfo",       function(object) standardGeneric("otherInfo"))
setGeneric("pData",           function(object) standardGeneric("pData"))
setGeneric("pData<-",         function(object, value) standardGeneric("pData<-"))
setGeneric("phenoData",       function(object) standardGeneric("phenoData"))
setGeneric("phenoData<-",     function(object, value) standardGeneric("phenoData<-"))
setGeneric("preproc",         function(object) standardGeneric("preproc"))
setGeneric("preproc<-",       function(object, value) standardGeneric("preproc<-"))
setGeneric("pubMedIds",       function(object) standardGeneric("pubMedIds"))
setGeneric("pubMedIds<-",     function(object,value) standardGeneric("pubMedIds<-"))
setGeneric("reporterInfo",    function(object) standardGeneric("reporterInfo"))
setGeneric("reporterInfo<-",  function(object, value) standardGeneric("reporterInfo<-"))
setGeneric("reporterNames",   function(object) standardGeneric("reporterNames"))
setGeneric("reporterNames<-", function(object, value) standardGeneric("reporterNames<-"))
setGeneric("sampleNames",     function(object) standardGeneric("sampleNames"))
setGeneric("sampleNames<-",   function(object, value) standardGeneric("sampleNames<-"))
setGeneric("samples",         function(object) standardGeneric("samples"))
setGeneric("se.exprs",        function(object) standardGeneric("se.exprs"))
setGeneric("se.exprs<-",      function(object, value) standardGeneric("se.exprs<-"))
setGeneric("split")
setGeneric("selectSomeIndex",   function(object, ...) standardGeneric("selectSomeIndex"))
setGeneric("storageMode",     function(object) standardGeneric("storageMode"))
setGeneric("storageMode<-",   function(object, value) standardGeneric("storageMode<-"))
setGeneric("varLabels",       function(object) standardGeneric("varLabels"))
setGeneric("varLabels<-",     function(object, value) standardGeneric("varLabels<-"))
setGeneric("varMetadata",     function(object) standardGeneric("varMetadata"))
setGeneric("varMetadata<-",   function(object, value) standardGeneric("varMetadata<-"))
setGeneric("update2MIAME",    function(object) standardGeneric("update2MIAME"))
setGeneric("write.exprs",     function(x,...) standardGeneric("write.exprs"))
## Version-related generics
setGeneric("classVersion",    function(object) standardGeneric("classVersion"))
setGeneric("classVersion<-",  function(object, value) standardGeneric("classVersion<-"))
setGeneric("isCurrent",       function(object, value) standardGeneric("isCurrent"))
setGeneric("isVersioned",     function(object) standardGeneric("isVersioned"))
## updateObject
setGeneric("updateObject",
           function(object, ..., verbose=FALSE) {
               result <- standardGeneric("updateObject")
               validObject(result)
               result
           })
setGeneric("updateObjectTo",
           function(object, template, ..., verbose=FALSE) {
               result <- standardGeneric("updateObjectTo")
               if (!is(result, class(template))) # or strict equality?
                 stop("updateObjectTo returned class '", class(result), "' ",
                      "expected class '", class(template), "'")
               validObject(result)
               result
           })

