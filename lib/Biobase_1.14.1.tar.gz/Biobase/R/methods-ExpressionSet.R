setMethod("initialize", "ExpressionSet",
          function(.Object,
                   assayData,
                   phenoData = annotatedDataFrameFrom(assayData, byrow=FALSE),
                   featureData = annotatedDataFrameFrom(assayData, byrow=TRUE),
                   experimentData = new("MIAME"),
                   annotation = character(),
                   exprs = new("matrix"),
                   ... ) {
              if (missing(assayData)) {
                  if (missing(phenoData))
                    phenoData <- annotatedDataFrameFrom(exprs, byrow=FALSE)
                  if (missing(featureData))
                    featureData <- annotatedDataFrameFrom(exprs, byrow=TRUE)
                  .Object <- callNextMethod(.Object,
                                            phenoData=phenoData,
                                            featureData=featureData,
                                            experimentData=experimentData,
                                            annotation=annotation,
                                            exprs=exprs,
                                            ...)
              } else if (missing(exprs)) {
                  .Object <- callNextMethod(.Object,
                                            assayData = assayData,
                                            phenoData = phenoData,
                                            featureData = featureData,
                                            experimentData = experimentData,
                                            annotation = annotation,
                                            ...)
              } else stop("provide at most one of 'assayData' or 'exprs' to initialize ExpressionSet",
                          call.=FALSE)
              .harmonizeDimnames(.Object)
          })

.harmonizeDimnames <- function(object) {
    err <- function(conflicts)
        stop("assayData element dimnames conflict: ",
             paste(names(conflicts), collapse=", "))
    okNames <- list(featureNames(featureData(object)),
                    sampleNames(phenoData(object)))
    dimNames <- .assayDataDimnames(assayData(object))
    dimConflict <- function(dimNames, okNames, dim) {
        nm <- lapply(dimNames, "[[", dim)
        isConflict <- !sapply(nm, identical, okNames[[dim]])
        isNull <- sapply(nm, is.null)
        if (all(!isConflict & !isNull))
            return (FALSE)
        if (any(isConflict & !isNull))
            err(isConflict[!isNull])
        TRUE
    }
    if (dimConflict(dimNames, okNames, 1))
        featureNames(assayData(object)) <- okNames[[1]]
    if (dimConflict(dimNames, okNames, 2))
        sampleNames(assayData(object)) <- okNames[[2]]
    object
}

setAs("exprSet", "ExpressionSet", function(from) {
  desc <- description(from)
  desc <- 
    if (class(desc)!="MIAME") {
        warning("missing or mis-formed MIAME 'description' in original object; creating new, empty description")
        new("MIAME")
    } else updateObject(desc)
  exprs <- assayData(from)
  dims <- dim(exprs)
  if (all(dim(from@se.exprs) == dims)) {
    se.exprs <- from@se.exprs
    colnames(se.exprs) <- colnames(exprs)
    new("ExpressionSet",
        phenoData=as(phenoData(from), "AnnotatedDataFrame"),
        experimentData=desc,
        annotation=annotation(from),
        exprs=exprs,
        se.exprs=se.exprs)
  } else {
    warning("missing or mis-shaped 'se.exprs' in original object; creating ExpressionSet without se.exprs")
    new("ExpressionSet",
        phenoData=as(phenoData(from), "AnnotatedDataFrame"),
        experimentData=desc,
        annotation=annotation(from),
        exprs=exprs)
  }
})

setValidity("ExpressionSet", function(object) {
    msg <- validMsg(NULL, isValidVersion(object, "ExpressionSet"))
    msg <- validMsg(msg, assayDataValidMembers(assayData(object), c("exprs")))
    if (is.null(msg)) TRUE else msg
})

setAs("ExpressionSet", "data.frame",
      function (from) data.frame(t(exprs(from)), pData(from)))

as.data.frame.ExpressionSet <- function(x, row.names=NULL, optional=FALSE, ...)
  as(x, "data.frame")

setMethod("exprs", signature(object="ExpressionSet"),
          function(object) assayDataElement(object,"exprs"))

setReplaceMethod("exprs", signature(object="ExpressionSet",value="matrix"),
                 function(object, value) assayDataElementReplace(object, "exprs", value))


setMethod("geneNames", signature(object="ExpressionSet"),
          function(object) {
              .Deprecated("featureNames")
              featureNames(object)
          })


setReplaceMethod("geneNames", signature(object="ExpressionSet",
                                        value="character"),
          function(object, value) {
              .Deprecated("featureNames")
              ## FIXME: check length and uniqueness?
              ##        call validObject?
              featureNames(object) <- value
          })

setMethod("makeDataPackage",
          signature(object="ExpressionSet"),
          function(object, author, email,
                   packageName, packageVersion, license, biocViews, filePath, ...) {
              if( missing(email) || !(is.character(email) && (length(email) == 1)
                                      && grep("@", email) == 1 ) )
                stop("invalid email address")

              sym = list(
                AUTHOR = author,
                VERSION=as.character(package_version(packageVersion)),
                LICENSE=license,
                TITLE = paste("Experimental Data Package:",packageName),
                MAINTAINER = paste(author, ", <", email, ">", sep = ""),
                BVIEWS = biocViews,
                DESCRIPTION = "place holder 1",
                FORMAT = pD2Rd(phenoData(object)))

              res = createPackage(packageName, destinationDir=filePath,
                originDir = system.file("ExpressionSet", package="Biobase"),
                symbolValues = sym, unlink=TRUE)

              ##save the data file
              datadir = file.path(res$pkgdir, "data")
              dir.create(datadir, showWarnings=FALSE)
              outfile = file.path(datadir, paste(packageName, ".rda", sep=""))
              assign(packageName, object)
              save(list=packageName, file = outfile)

              return(res)
          })

setMethod("write.exprs",
          signature(x="ExpressionSet"),
          function(x, file="tmp.txt", quote=FALSE,
                   sep="\t", col.names=NA, ...){
            write.table(exprs(x), file=file, quote=quote, sep=sep,
                        col.names=col.names, ...)
          })

readExpressionSet <- function(exprsFile,
                              phenoDataFile=character(0),
                              experimentDataFile=character(0),
                              notesFile=character(0),
                              annotation=character(0),
                              ## arguments to read.* methods 
                              exprsArgs=list(...),
                              phenoDataArgs=list(...),
                              experimentDataArgs=list(...),
                              notesArgs=list(...),
                              ## widget
                              widget = getOption("BioC")$Base$use.widgets,
                              ...) {
    if (!missing(widget) && widget != FALSE)
        stop("sorry, widgets not yet available")
    ## exprs
    if (missing(exprsFile))
        stop("exprs can not be missing!")
    exprsArgs$file=exprsFile
    exprs <- as.matrix(do.call("read.table", exprsArgs))
    obj <- new("ExpressionSet", exprs=exprs)
    ## phenoData
    if (!missing(phenoDataFile))
        phenoDataArgs$file=phenoDataFile
    if (is.null(phenoDataArgs$sampleNames))
        phenoDataArgs$sampleNames=colnames(exprs)
    if (!is.null(phenoDataArgs$file))
        phenoData(obj) <- do.call("read.AnnotatedDataFrame", phenoDataArgs)
    ## experimentData
    if (!missing(experimentDataFile))
        experimentDataArgs$file=experimentDataFile
    if (!is.null(experimentDataArgs$file))
        experimentData(obj) <- do.call("read.MIAME", experimentDataArgs)
    ## annotation
    if (!missing(annotation))
        annotation(obj) <- annotation
    ## notes
    if (!missing(notesFile))
        notesArgs$file=notesFile
    if (!is.null(notesArgs$file))
        notes(obj) <- readLines(notesFile)
    validObject(obj)
    obj
}

