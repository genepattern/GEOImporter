#!/bin/bash

R --slave < runalltests.R
